#!/bin/sh
exec true
